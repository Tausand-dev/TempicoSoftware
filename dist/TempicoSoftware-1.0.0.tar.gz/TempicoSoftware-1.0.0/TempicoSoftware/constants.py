#File of constants for scripts
ICON_LOCATION="./Sources/abacus_small.ico"
VERSION="1.0.0"
BANNER="./Sources/splash.png"
#Create the taskbarIcon for windows with ctypes
APPID="tempico.tempico.01"
