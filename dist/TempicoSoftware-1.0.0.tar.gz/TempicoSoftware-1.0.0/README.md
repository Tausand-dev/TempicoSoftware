# TempicoSoftware
software with GUI to easily use Tausand Tempico TP1000 devices (Python based)
